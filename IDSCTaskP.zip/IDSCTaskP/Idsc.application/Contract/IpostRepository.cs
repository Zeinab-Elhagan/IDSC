﻿using IDSCTask;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Idsc.application.Contract.persistence
{
    public interface IpostRepository : IASyncRopostory<post>
    {
        Task<IReadOnlyList<post>> GetAllpostAsync(bool includeCategory);
        Task<post> GetpostByIdAsync(Guid id, bool includeCategory);
    }
}
