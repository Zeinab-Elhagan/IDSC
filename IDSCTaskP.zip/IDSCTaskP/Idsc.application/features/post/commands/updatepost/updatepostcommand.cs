﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Idsc.application.features.post.commands.updatepost
{
    public class updatepostcommand : IRequest
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string ImageUrl { get; set; }
        public string conent { get; set; }
        public Guid CategoryId { get; set; }
    }
}
