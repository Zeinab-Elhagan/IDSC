﻿using AutoMapper;
using Azure.Core;
using Idsc.application.features.post.queries.getpostslist;
using Idsc;
using Idsc.application.Contract.persistence;
using Idsc.application.features.post;
using IDSCTask;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Idsc.application.features.post.commands.updatepost
{
    public class updatepostcommandhandler : IRequestHandler<updatepostcommand>
    {
        private readonly IpostRepository _postRepository;
        private readonly Imapper _imapper;
        private object postRepository;

        public updatepostcommandhandler(IASyncRopostory<post> postRepository, Imapper Mapper)
        {
            _postRepository = postRepository;
            _mapper = Mapper;
        }
        public async Task<Unit> Handle<updatepostcommand Request, CancellationToken cancellation>
        {
            post post = IMapper.Map<post>(Request);

            await _postRepository.updateAsync(post);
            return Unit value;
        }



        Task<Unit> IRequestHandler<updatepostcommand, Unit>.Handle(updatepostcommand request, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
