﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Azure.Core;
using MediatR;
using Idsc.application.features.post.queries.getpostslist;

using Idsc.application.Contract.persistence;
using YamlDotNet.Core.Tokens;
//using YamlDotNet.Core.Tokens;

namespace Idsc.application.features.post.commands.deletepost
{
    public class deletpostcommandhandler : IRequestHandler<deletpostcommand>
    {
        private readonly IpostRepository _postRepository;
        public deletpostcommandhandler(IpostRepository postRepository)
        {
            _postRepository = postRepository;
        }
        public async Task<Unit> Handle(deletpostcommand Request, CancellationToken cancellation)
        {
            var post = await _postRepository.GetByIdAsync(Request.postId);

            await _postRepository.DeleteAsync(post);

            return Unit.Value;
        }
    }
}
