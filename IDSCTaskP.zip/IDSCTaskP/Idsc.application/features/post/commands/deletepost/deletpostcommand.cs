﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Idsc.application.features.post.commands.deletepost
{
    public class deletpostcommand
    {
        public Guid postId { get; set; }
    }
}
