﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Idsc.application.features.post.commands.createpost
{
    public class creatpostcomand : IRequest<Guid>
    {
        public string Title { get; set; }
        public string ImageUrl { get; set; }
        public string content { get; set; }
        public Guid catogeryId { get; set; }
    }
}
