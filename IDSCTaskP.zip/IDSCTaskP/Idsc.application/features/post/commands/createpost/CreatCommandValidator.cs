﻿using FluentValidation;




namespace Idsc.application.features.post.commands.createpost
{
    public class CreatCommandValidator : AbstractValidator<creatpostcomand>
    {
        public CreatCommandValidator()
        {
            RuleFor(p => p.Title)
                .NotEmpty()
                .NotNull()
              .MaximumLength(100);
            RuleFor(p => p.content)
                .NotEmpty()
                .NotNull();

        }

        public Task validateAsync(createpostcommandhandler request)
        {
            throw new NotImplementedException();
        }
    }
}