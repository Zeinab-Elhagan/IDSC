﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediatR;
using Idsc.application.Contract.persistence;
using AutoMapper;
using Idsc.application.features.post.queries.getpostslist;
using FluentValidation;

namespace Idsc.application.features.post.commands.createpost
{
    public class createpostcommandhandler : IRequestHandler<creatpostcomand,Guid>
    {
        private readonly IpostRepository _postRepository;
        private readonly Imapper _imapper;
        private object postRepository;

        public Task<Guid> Handle(creatpostcomand request, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        public createpostcommandhandler(IpostRepository postRepository, Imapper Mapper)
        {
            postRepository = postRepository;
            Mapper = Mapper;
        }
        public async Task<Guid> Handle(createpostcommandhandler request, CancellationToken cancellation)
        {
            post post = _mapper.Map<post>(request);

            CreatCommandValidator validator = new CreatCommandValidator();

            var result = await validator.validateAsync(request);

            if (result.Errors.Any())
            {
                throw new Exception("post  is not valid");
            }


            post = await _postRepository.AddAsync(post);
            return post.Id;
        }
    }

}

