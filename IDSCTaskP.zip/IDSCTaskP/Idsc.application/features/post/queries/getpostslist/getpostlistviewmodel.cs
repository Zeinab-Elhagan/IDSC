﻿using System;


namespace Idsc.application.features.post.queries.getpostslist
{
    public  class getpostlistviewmodel
    {
        public Guid Id { get; set;}
        public string Title { get; set;}
        public string ImageUrl { get; set;}
        public CatogeryDto catogery { get; set;}


    }
}
