﻿using System;
using MediatR;
using System.Collections.Generic;


namespace Idsc.application.features.post.queries.getpostslist
{
  public class getpostlistqueries : MediatR.IRequest<List<getpostlistviewmodel>>
    {
        
    }
}
