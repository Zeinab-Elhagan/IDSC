﻿using Idsc.application.Contract.persistence;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Idsc.application;

namespace Idsc.application.features.post.queries.getpostslist
{
    public class getpostlistqueryhandler : IRequestHandler<getpostlistqueries, List<getpostlistviewmodel>>
    {
        private readonly IpostRepository _postRepository;
        private readonly Imapper _imapper;
        private object postRepository;

        public getpostlistqueryhandler(IpostRepository postRepository, Imapper _mapper)
        {
            postRepository = postRepository;
            _mapper = _mapper;
        }
        public async Task<List<getpostlistviewmodel>> Handle(getpostlistqueries request, CancellationToken cancellation)
        {
            var allposts = await postRepository.GetAllpostsAsync(true);

            return Imapper.map<List<getpostlistviewmodel>>(allposts);
        }


    }
}




