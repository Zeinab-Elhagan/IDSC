﻿namespace Idsc.application.features.post.queries.getpostslist
{
    internal class Imapper
    {
        internal static T map<T>(object allposts)
        {
            throw new NotImplementedException();
        }
    }
}