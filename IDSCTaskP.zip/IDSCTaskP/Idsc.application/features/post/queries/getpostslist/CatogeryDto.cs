﻿using System;


namespace Idsc.application.features.post.queries.getpostslist
{
  public class CatogeryDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
