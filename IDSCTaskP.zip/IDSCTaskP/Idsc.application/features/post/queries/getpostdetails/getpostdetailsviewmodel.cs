﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Idsc.application.features.post.queries.getpostslist;

namespace Idsc.application.features.post.queries.getpostdetails
{
    public class getpostdetailsviewmodel
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string ImageUrl { get; set; }
        public string content { get; set; }
        public CatogeryDto catogery { get; set; }
    }
}
