﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediatR;

namespace Idsc.application.features.post.queries.getpostdetails
{
    public class getpostdetailsquery : IRequest<getpostdetailsviewmodel>
    {
        public Guid postId { get; set; }

    }
}
