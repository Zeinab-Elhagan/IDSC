﻿using System;
using System.Collections.Generic;
using MediatR;
using Idsc.application.Contract.persistence;
using AutoMapper;

namespace Idsc.application.features.post.queries.getpostdetails
{
    public class getpostdetailqueryhandler : IRequestHandler<getpostdetailsquery, getpostdetailsviewmodel>
    {
        private readonly IpostRepository repository;
        private readonly IMapper mapper;
        public getpostdetailqueryhandler(IpostRepository postrepository, IMapper mapper)
        {
            postrepository = postrepository;
            mapper = mapper;
        }
        public async Task<getpostdetailsviewmodel> Handle(getpostdetailsquery request, CancellationToken cancellationToken)

        {
            var post = await postRepository.getpostByIdAsync(request.postId, true);

                return Mapper.Map<getpostdetailsviewmodel>(post);
        }
    }

}






