﻿using System;
using AutoMapper;
using FluentValidation;
using IDSCTask;
using Idsc.application.features.post.queries.getpostslist;
using Idsc.application.features.post.queries.getpostdetails;
using Idsc.application.features.post.commands.createpost;

namespace Idsc.application.profiles
{
    public class automapperprofil : Profile
    {
        public class Aeutomapperprofile
        {
           // CreateMap<post,getpostlistviewmodel>().ReverseMap();
           // CreateMap<post, getpostdetailsviewmodel>().ReverseMap();
           // CreateMap<post,creatpostcomand>().ReverseMap();
        }
    }
}
