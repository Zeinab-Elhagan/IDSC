﻿using Idsc.application.Contract.persistence;
using IDSC.Persistence;
using IDSCTask;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PostLand.Persistence
{
    public class PostRepository : baserepository<post>, IpostRepository
    {
        public PostRepository(PostDbContext postDbContext) : base(postDbContext)
        {

        }

        public Task<IReadOnlyList<post>> GetAllpostAsync(bool includeCategory)
        {
            throw new NotImplementedException();
        }

        public async Task<IReadOnlyList<post>> GetAllPostsAsync(bool includeCategory)
        {
            List<post> allPosts = new List<post>();
            allPosts = includeCategory ? await _dbContext.Posts.Include(x => x.category).ToListAsync() : await _dbContext.Posts.ToListAsync();
            return allPosts;
        }

        public async Task<post> GetPostByIdAsync(Guid id, bool includeCategory)
        {
            post Post = new post();
            Post = includeCategory ? await _dbContext.Posts.Include(x => x.category).FirstOrDefaultAsync(x => x.Id == id) : await GetByIdAsync(id);
            return Post;
        }

        public Task<post> GetpostByIdAsync(Guid id, bool includeCategory)
        {
            throw new NotImplementedException();
        }
    }

}