﻿using Microsoft.EntityFrameworkCore;
using IDSC.Persistence;
using Idsc.application.Contract.persistence;

namespace PostLand.Persistence
{
    public partial class baserepository<T> : IASyncRopostory<T> where T : class
    {
        protected readonly PostDbContext _dbContext;

        public baserepository(PostDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public virtual async Task<T> GetByIdAsync(Guid id)
        {
            return await _dbContext.Set<T>().FindAsync(id);
        }

        public async Task<IReadOnlyList<T>> ListAllAsync()
        {
            return await _dbContext.Set<T>().ToListAsync();
        }

        public async Task<T> AddAsync(T entity)
        {
            await _dbContext.Set<T>().AddAsync(entity);
            await _dbContext.SaveChangesAsync();

            return entity;
        }

        public async Task UpdateAsync(T entity)
        {
            _dbContext.Entry(entity).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteAsync(T entity)
        {
            _dbContext.Set<T>().Remove(entity);
            await _dbContext.SaveChangesAsync();
        }

        public Task<IReadOnlyList<T>> ListALLAsync()
        {
            throw new NotImplementedException();
        }

        public Task updateAsync(T entity)
        {
            throw new NotImplementedException();
        }
    }

}