﻿using System;
using IDSC.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using PostLand.Persistence;

namespace PostLand.Persistence.Migrations
{
    [DbContext(typeof(PostDbContext))]
    [Migration("20210620160232_InitialMigration")]
    partial class InitialMigration
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
#pragma warning disable 612, 618
            modelBuilder
                .HasAnnotation("Relational:MaxIdentifierLength", 128)
                .HasAnnotation("ProductVersion", "6.0.0-preview.1.21102.2")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("PostLand.Domain.Category", b =>
            {
                b.Property<Guid>("Id")
                    .ValueGeneratedOnAdd()
                    .HasColumnType("uniqueidentifier");

                b.Property<string>("Name")
                    .HasColumnType("nvarchar(max)");

                b.HasKey("Id");

                b.ToTable("Category");

                b.HasData(
                    new
                    {
                        Id = new Guid("b0788d2f-8003-43c1-92a4-edc76a7c5dde"),
                        Name = "Technology"
                    });
            });

            modelBuilder.Entity("PostLand.Domain.Post", b =>
            {
                b.Property<Guid>("Id")
                    .ValueGeneratedOnAdd()
                    .HasColumnType("uniqueidentifier");

                b.Property<Guid>("CategoryId")
                    .HasColumnType("uniqueidentifier");

                b.Property<string>("Content")
                    .HasColumnType("nvarchar(max)");

                b.Property<string>("ImageUrl")
                    .HasColumnType("nvarchar(max)");

                b.Property<string>("Title")
                    .HasColumnType("nvarchar(max)");

                b.HasKey("Id");

                b.HasIndex("CategoryId");

                b.ToTable("Posts");

                b.HasData(
                    new
                    {
                        Id = new Guid("6313179f-7837-473a-a4d5-a5571b43e6a6"),
                        CategoryId = new Guid("b0788d2f-8003-43c1-92a4-edc76a7c5dde"),
                        Content = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat",
                        ImageUrl = "https://api.khalidessaadani.com/uploads/articles_bg.jpg",
                        Title = "Introduction to CQRS and Mediator Patterns"
                    });
            });

            modelBuilder.Entity("PostLand.Domain.Post", b =>
            {
                b.HasOne("PostLand.Domain.Category", "Category")
                    .WithMany("Blogs")
                    .HasForeignKey("CategoryId")
                    .OnDelete(DeleteBehavior.Cascade)
                    .IsRequired();

                b.Navigation("Category");
            });

            modelBuilder.Entity("PostLand.Domain.Category", b =>
            {
                b.Navigation("Blogs");
            });
#pragma warning restore 612, 618
        }
    }
}