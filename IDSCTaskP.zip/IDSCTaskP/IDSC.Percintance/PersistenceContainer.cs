﻿//using IDSC.Application.Contracts.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using IDSC.Persistence;
using Idsc.application.Contract.persistence;

namespace PostLand.Persistence
{
    public static class PersistenceContainer
    {
        public static IServiceCollection AddPersistenceServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<PostDbContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("PostConnectionString")));

            services.AddScoped(typeof(IASyncRopostory<>), typeof(baserepository<>));
            services.AddScoped(typeof(IpostRepository), typeof(PostRepository));

            return services;
        }
    }

}