﻿using System;

namespace IDSCTask
{
    public class post
    {
        public Guid Id { get; set; } 
        public string Title { get; set; }      
        public string ImageUrL { get; set; }
        public string content { get; set; }
        public category category { get; set; }
        public Guid categoryId { get; set; }
    }
}
