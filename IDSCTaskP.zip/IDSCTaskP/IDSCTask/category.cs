﻿namespace IDSCTask
{
    public class category
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public ICollection<post> Bolgs { get; set; }

    }
}
